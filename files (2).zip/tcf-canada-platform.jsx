'use client'

import React, { useState, useEffect } from 'react'
import { ChevronRight, Timer, Lock, BarChart3, LogOut, Play, RotateCcw } from 'lucide-react'

// Sample quiz data - In production, this would come from your database
const COMPREHENSION_DATA = {
  ecrite: {
    title: 'Compréhension Écrite',
    description: 'Lisez des textes et répondez aux questions',
    paid: true,
    freeQuizzes: 3,
    totalQuestions: 39,
    questions: [
      {
        id: 1,
        number: 40,
        text: 'Vous êtes étudiant, vous cherchez un logement...',
        question: 'Que propose le site jeunes gouv.fr ?',
        image: '37q1.png',
        options: {
          A: "D'acheter un appartement.",
          B: "D'habiter avec quelqu'un.",
          C: 'De rencontrer ses voisins.',
          D: 'De visiter son quartier.'
        },
        correct: 'B'
      },
      {
        id: 2,
        number: 41,
        text: 'Mathilde, Je t\'attends devant l\'entrée du stade...',
        question: 'Pourquoi est-ce que Laura attend Mathilde?',
        image: '37q2.png',
        options: {
          A: 'Pour aller visiter un musée',
          B: 'Pour participer à un concours.',
          C: 'Pour prendre un café ensemble.',
          D: 'Pour voir un événement sportif.'
        },
        correct: 'D'
      },
      {
        id: 3,
        number: 42,
        text: 'Jean n\'oublie pas d\'aller chercher les enfants...',
        question: 'Que doit faire Jean ?',
        image: '37q3.png',
        options: {
          A: 'Aller à une réunion.',
          B: 'Déjeuner avec Claudia.',
          C: "S'occuper des enfants.",
          D: 'Téléphoner à l\'école.'
        },
        correct: 'C'
      }
    ]
  },
  orale: {
    title: 'Compréhension Orale',
    description: 'Écoutez des enregistrements et répondez',
    paid: true,
    freeQuizzes: 3,
    totalQuestions: 39,
    questions: []
  }
}

// Quiz Component
function QuizComponent({ quizType, onBack }) {
  const quizData = COMPREHENSION_DATA[quizType]
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [timeLeft, setTimeLeft] = useState(45 * 60) // 45 minutes in seconds
  const [started, setStarted] = useState(false)

  useEffect(() => {
    if (!started) return

    const interval = setInterval(() => {
      setTimeLeft(t => t - 1)
    }, 1000)

    return () => clearInterval(interval)
  }, [started])

  const handleAnswer = (option) => {
    setAnswers(prev => ({
      ...prev,
      [currentQuestion]: option
    }))
  }

  const handleNext = () => {
    if (currentQuestion < quizData.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleSubmit = () => {
    setShowResults(true)
  }

  const calculateScore = () => {
    let correct = 0
    quizData.questions.forEach((q, index) => {
      if (answers[index] === q.correct) correct++
    })
    return correct
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`
  }

  if (showResults) {
    const score = calculateScore()
    const percentage = Math.round((score / quizData.questions.length) * 100)

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={onBack}
            className="mb-8 flex items-center gap-2 text-indigo-600 hover:text-indigo-700 font-semibold"
          >
            ← Retour aux Quiz
          </button>

          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Résultats</h2>
            
            <div className="my-12">
              <div className="text-6xl font-bold text-indigo-600 mb-4">
                {score}/{quizData.questions.length}
              </div>
              <div className="text-2xl font-semibold text-gray-700 mb-8">
                {percentage}%
              </div>

              <div className="w-full bg-gray-200 rounded-full h-4 mb-8">
                <div
                  className="bg-indigo-600 h-4 rounded-full transition-all duration-500"
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>

              {percentage >= 80 && (
                <p className="text-xl text-green-600 font-semibold mb-4">
                  ✓ Excellent résultat!
                </p>
              )}
              {percentage >= 60 && percentage < 80 && (
                <p className="text-xl text-blue-600 font-semibold mb-4">
                  ✓ Bon résultat, continuez vos efforts!
                </p>
              )}
              {percentage < 60 && (
                <p className="text-xl text-orange-600 font-semibold mb-4">
                  ✓ À retravailler, réessayez!
                </p>
              )}
            </div>

            <button
              onClick={onBack}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Retour aux Quiz
            </button>
          </div>
        </div>
      </div>
    )
  }

  if (!started) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={onBack}
            className="mb-8 flex items-center gap-2 text-indigo-600 hover:text-indigo-700 font-semibold"
          >
            ← Retour
          </button>

          <div className="bg-white rounded-2xl shadow-lg p-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">{quizData.title}</h2>
            <p className="text-gray-600 mb-8">{quizData.description}</p>

            <div className="bg-indigo-50 p-6 rounded-lg mb-8">
              <h3 className="font-semibold text-gray-800 mb-4">Informations du Quiz:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>⏱️ Durée: 45 minutes</li>
                <li>📝 Questions: {quizData.questions.length}</li>
                <li>✓ Réponses multiples (A, B, C, D)</li>
                <li>📊 Résultats immédiats après soumission</li>
              </ul>
            </div>

            <button
              onClick={() => setStarted(true)}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-8 rounded-lg transition-colors flex items-center justify-center gap-2 text-lg"
            >
              <Play size={24} />
              Commencer le Quiz
            </button>
          </div>
        </div>
      </div>
    )
  }

  const question = quizData.questions[currentQuestion]
  const selected = answers[currentQuestion]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-800">{quizData.title}</h1>
          <div className="flex items-center gap-2 bg-white rounded-lg px-4 py-2 shadow">
            <Timer size={20} className="text-indigo-600" />
            <span className="font-bold text-lg text-gray-800">
              {formatTime(timeLeft)}
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm font-semibold text-gray-600 mb-2">
            <span>Question {currentQuestion + 1}/{quizData.questions.length}</span>
            <span>{Math.round(((currentQuestion + 1) / quizData.questions.length) * 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-indigo-600 h-2 rounded-full transition-all duration-500"
              style={{
                width: `${((currentQuestion + 1) / quizData.questions.length) * 100}%`
              }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6">
            {question.question}
          </h2>

          {/* Image Placeholder */}
          <div className="bg-gray-100 rounded-lg mb-8 h-48 flex items-center justify-center">
            <div className="text-center">
              <img
                src={`/images/${question.image}`}
                alt="Question"
                className="max-h-48 object-contain rounded"
                onError={(e) => {
                  e.target.style.display = 'none'
                }}
              />
              {question.image && (
                <p className="text-gray-500 mt-2">{question.image}</p>
              )}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {Object.entries(question.options).map(([key, value]) => (
              <button
                key={key}
                onClick={() => handleAnswer(key)}
                className={`w-full p-4 text-left rounded-lg border-2 transition-all font-medium ${
                  selected === key
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                    : 'border-gray-200 bg-white text-gray-800 hover:border-indigo-300'
                }`}
              >
                <span className="font-bold text-lg">{key}.</span> {value}
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between gap-4">
          <button
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="px-6 py-3 bg-white text-indigo-600 border-2 border-indigo-600 rounded-lg font-bold hover:bg-indigo-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            ← Précédent
          </button>

          {currentQuestion === quizData.questions.length - 1 ? (
            <button
              onClick={handleSubmit}
              className="flex-1 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition-colors"
            >
              Soumettre le Quiz
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="flex-1 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold transition-colors flex items-center justify-center gap-2"
            >
              Suivant <ChevronRight size={20} />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// Dashboard Component
function Dashboard({ onSelectQuiz, userSubscription = 'free' }) {
  const [selectedType, setSelectedType] = useState(null)

  if (selectedType) {
    return (
      <QuizComponent
        quizType={selectedType}
        onBack={() => setSelectedType(null)}
      />
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="max-w-6xl mx-auto px-8 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-indigo-600">TCF Canada</h1>
            <p className="text-gray-600">Préparation aux Examens</p>
          </div>
          <div className="flex items-center gap-4">
            {userSubscription === 'free' ? (
              <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg transition-colors">
                S'abonner
              </button>
            ) : (
              <div className="text-right">
                <p className="text-sm text-gray-600">Abonnement actif</p>
                <p className="font-bold text-indigo-600">Premium</p>
              </div>
            )}
            <button className="text-gray-600 hover:text-gray-800 p-2">
              <LogOut size={24} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-8 py-12">
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Compréhension</h2>
          <p className="text-gray-600 mb-8">
            Améliorez vos compétences en compréhension écrite et orale
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Compréhension Écrite */}
            <div
              onClick={() => setSelectedType('ecrite')}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer group"
            >
              <div className="h-32 bg-gradient-to-br from-blue-400 to-indigo-600 relative">
                <div className="absolute inset-0 flex items-center justify-center text-5xl opacity-20">
                  📄
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  Compréhension Écrite
                </h3>
                <p className="text-gray-600 mb-6">
                  Lisez des textes et répondez aux questions
                </p>

                <div className="space-y-2 text-sm text-gray-700 mb-6">
                  <p>⏱️ 45 minutes</p>
                  <p>📝 39 Questions</p>
                  <p>
                    {userSubscription === 'free' ? (
                      <>
                        🔒 3 Quiz gratuits
                        <span className="text-indigo-600 font-semibold"> (S'abonner pour tous)</span>
                      </>
                    ) : (
                      '✓ Accès complet'
                    )}
                  </p>
                </div>

                <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg transition-colors group-hover:translate-y-[-2px]">
                  Commencer {userSubscription === 'free' ? '(Gratuit)' : ''}
                </button>
              </div>
            </div>

            {/* Compréhension Orale */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-not-allowed opacity-60">
              <div className="h-32 bg-gradient-to-br from-purple-400 to-pink-600 relative">
                <div className="absolute inset-0 flex items-center justify-center text-5xl opacity-20">
                  🎧
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  Compréhension Orale
                </h3>
                <p className="text-gray-600 mb-6">
                  Écoutez des enregistrements et répondez
                </p>

                <div className="space-y-2 text-sm text-gray-700 mb-6">
                  <p>⏱️ 30 minutes</p>
                  <p>🎧 39 Enregistrements</p>
                  <p className="text-gray-500">
                    <Lock size={16} className="inline mr-2" />
                    Bientôt disponible
                  </p>
                </div>

                <button
                  disabled
                  className="w-full bg-gray-400 text-white font-bold py-3 rounded-lg cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <Lock size={20} />
                  Bientôt
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <BarChart3 size={24} className="text-indigo-600" />
            Votre Progression
          </h2>
          <div className="grid grid-cols-3 gap-6">
            <div className="text-center p-4 border-l-4 border-indigo-600">
              <p className="text-4xl font-bold text-indigo-600">0</p>
              <p className="text-gray-600">Quiz Complétés</p>
            </div>
            <div className="text-center p-4 border-l-4 border-green-600">
              <p className="text-4xl font-bold text-green-600">0%</p>
              <p className="text-gray-600">Score Moyen</p>
            </div>
            <div className="text-center p-4 border-l-4 border-purple-600">
              <p className="text-4xl font-bold text-purple-600">0h</p>
              <p className="text-gray-600">Temps d'Étude</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Main App
export default function TCFCanadaApp() {
  return (
    <Dashboard userSubscription="free" />
  )
}
