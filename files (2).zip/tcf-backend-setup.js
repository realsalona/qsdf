// ============================================
// TCF CANADA PLATFORM - BACKEND SETUP GUIDE
// ============================================

// 1. DATABASE SCHEMA (Supabase/Firebase)
// ============================================

const databaseSchema = {
  // Users Table
  users: {
    id: 'uuid primary key',
    email: 'string unique',
    name: 'string',
    password_hash: 'string',
    subscription_type: 'enum (free, premium, lifetime)',
    subscription_start: 'timestamp',
    subscription_end: 'timestamp',
    stripe_customer_id: 'string',
    created_at: 'timestamp',
    updated_at: 'timestamp'
  },

  // Quiz Results Table
  quiz_results: {
    id: 'uuid primary key',
    user_id: 'uuid foreign key -> users.id',
    quiz_type: 'enum (comprehension_ecrite, comprehension_orale, expression_ecrite, expression_orale)',
    score: 'integer',
    total_questions: 'integer',
    percentage: 'integer',
    time_spent: 'integer (seconds)',
    answers: 'json object',
    completed_at: 'timestamp'
  },

  // Quiz Questions Table
  questions: {
    id: 'uuid primary key',
    quiz_type: 'enum',
    question_number: 'integer',
    text: 'text',
    question_prompt: 'string',
    image_url: 'string',
    audio_url: 'string (for orale)',
    options: 'json object',
    correct_answer: 'string',
    created_at: 'timestamp'
  },

  // Subscriptions Table
  subscriptions: {
    id: 'uuid primary key',
    user_id: 'uuid foreign key -> users.id',
    stripe_subscription_id: 'string',
    status: 'enum (active, canceled, expired)',
    plan: 'string',
    current_period_start: 'timestamp',
    current_period_end: 'timestamp',
    created_at: 'timestamp'
  }
}

// 2. STRIPE INTEGRATION SETUP
// ============================================

const stripeSetup = `
// Install Stripe packages
npm install stripe @stripe/react-stripe-js @stripe/stripe-js

// 1. Create Stripe Products in Dashboard:
// - Product: "TCF Canada Premium"
//   - Price: $19.99/month (recurring)
//   - Price ID: price_xxx

// 2. Backend Route for Checkout (Next.js API Route)
// File: app/api/stripe/checkout/route.js

import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export async function POST(req) {
  const { userId, email } = await req.json()

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [
      {
        price: process.env.STRIPE_PRICE_ID, // price_xxx
        quantity: 1
      }
    ],
    mode: 'subscription',
    customer_email: email,
    metadata: {
      user_id: userId
    },
    success_url: \`\${process.env.NEXTAUTH_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}\`,
    cancel_url: \`\${process.env.NEXTAUTH_URL}/pricing\`
  })

  return Response.json({ sessionId: session.id })
}

// 3. Webhook Handler for Stripe Events
// File: app/api/stripe/webhooks/route.js

export async function POST(req) {
  const body = await req.text()
  const sig = req.headers.get('stripe-signature')

  let event
  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    )
  } catch (err) {
    return Response.json({ error: 'Webhook error' }, { status: 400 })
  }

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated':
      // Update user subscription in database
      const subscription = event.data.object
      await updateUserSubscription(
        subscription.metadata.user_id,
        'premium',
        new Date(subscription.current_period_end * 1000)
      )
      break

    case 'customer.subscription.deleted':
      // Downgrade user to free
      await updateUserSubscription(
        subscription.metadata.user_id,
        'free',
        null
      )
      break
  }

  return Response.json({ received: true })
}

// 4. Environment Variables (.env.local)
STRIPE_PUBLIC_KEY=pk_test_xxx
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_PRICE_ID=price_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
NEXTAUTH_URL=http://localhost:3000
`

// 3. AUTHENTICATION SETUP
// ============================================

const authSetup = `
// Install NextAuth
npm install next-auth

// File: app/api/auth/[...nextauth]/route.js

import NextAuth from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { supabase } from '@/lib/supabase'

export const authOptions = {
  providers: [
    CredentialsProvider({
      async authorize(credentials) {
        const { data: { user }, error } = await supabase.auth.signInWithPassword({
          email: credentials.email,
          password: credentials.password
        })
        
        if (error || !user) return null
        
        // Get subscription info
        const { data: userData } = await supabase
          .from('users')
          .select('*')
          .eq('id', user.id)
          .single()
        
        return {
          id: user.id,
          email: user.email,
          subscription: userData?.subscription_type || 'free'
        }
      }
    })
  ],
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error'
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.subscription = user.subscription
      }
      return token
    },
    async session({ session, token }) {
      session.user.subscription = token.subscription
      return session
    }
  }
}

export const handler = NextAuth(authOptions)
`

// 4. QUIZ DATA MANAGEMENT
// ============================================

const quizManager = `
// File: lib/quizData.ts

export async function getQuizzes(userId: string, type: 'ecrite' | 'orale') {
  const { data: user } = await supabase
    .from('users')
    .select('subscription_type')
    .eq('id', userId)
    .single()

  // Get all questions
  const { data: questions } = await supabase
    .from('questions')
    .select('*')
    .eq('quiz_type', type)
    .order('question_number')

  // If free user, only return first 3 questions
  if (user?.subscription_type === 'free') {
    return questions.slice(0, 3)
  }

  return questions
}

export async function submitQuiz(
  userId: string,
  quizType: string,
  answers: Record<number, string>
) {
  const { data: questions } = await supabase
    .from('questions')
    .select('correct_answer')
    .eq('quiz_type', quizType)

  // Calculate score
  let score = 0
  questions.forEach((q, index) => {
    if (answers[index] === q.correct_answer) score++
  })

  // Save result
  await supabase.from('quiz_results').insert({
    user_id: userId,
    quiz_type: quizType,
    score,
    total_questions: questions.length,
    percentage: Math.round((score / questions.length) * 100),
    answers,
    completed_at: new Date()
  })

  return {
    score,
    percentage: Math.round((score / questions.length) * 100),
    total: questions.length
  }
}

export async function getUserProgress(userId: string) {
  const { data: results } = await supabase
    .from('quiz_results')
    .select('*')
    .eq('user_id', userId)

  const completed = results.length
  const averageScore = results.length > 0
    ? Math.round(
        results.reduce((sum, r) => sum + r.percentage, 0) / results.length
      )
    : 0

  const totalTime = results.reduce((sum, r) => sum + (r.time_spent || 0), 0)

  return {
    quizzesCompleted: completed,
    averageScore,
    totalTime
  }
}
`

// 5. PAYMENT BUTTON COMPONENT
// ============================================

const paymentComponent = `
// File: components/SubscribeButton.tsx

import { loadStripe } from '@stripe/stripe-js'
import { useSession } from 'next-auth/react'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY!)

export function SubscribeButton() {
  const { data: session } = useSession()
  const [loading, setLoading] = React.useState(false)

  const handleSubscribe = async () => {
    setLoading(true)

    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: session?.user?.id,
          email: session?.user?.email
        })
      })

      const { sessionId } = await res.json()
      const stripe = await stripePromise
      await stripe?.redirectToCheckout({ sessionId })
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <button
      onClick={handleSubscribe}
      disabled={loading}
      className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-lg transition-colors disabled:opacity-50"
    >
      {loading ? 'Redirection...' : 'S\'abonner à Premium - 19.99\$/mois'}
    </button>
  )
}
`

// 6. PROTECTED QUIZ COMPONENT
// ============================================

const protectedQuiz = `
// File: components/ProtectedQuiz.tsx

import { useSession } from 'next-auth/react'
import { SubscribeButton } from './SubscribeButton'

export function ProtectedQuiz({ quizType }) {
  const { data: session, status } = useSession()
  const [questions, setQuestions] = React.useState([])

  React.useEffect(() => {
    if (status === 'authenticated') {
      fetchQuestions()
    }
  }, [status])

  const fetchQuestions = async () => {
    const res = await fetch(\`/api/quizzes/\${quizType}\`)
    const data = await res.json()
    setQuestions(data)
  }

  if (status === 'loading') {
    return <div>Chargement...</div>
  }

  if (!session) {
    return <SignInButton />
  }

  // Check if user is free and quiz is paid
  if (session.user.subscription === 'free' && questions.length < 39) {
    return (
      <div className="text-center p-8">
        <h2 className="text-2xl font-bold mb-4">Accès Premium Requis</h2>
        <p className="text-gray-600 mb-6">
          Seuls les 3 premiers quiz sont gratuits.
          Abonnez-vous pour accéder à tous les quiz!
        </p>
        <SubscribeButton />
      </div>
    )
  }

  return <QuizComponent questions={questions} />
}
`

module.exports = {
  databaseSchema,
  stripeSetup,
  authSetup,
  quizManager,
  paymentComponent,
  protectedQuiz
}
