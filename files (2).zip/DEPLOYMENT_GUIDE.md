# TCF Canada Platform - Complete Deployment Guide

## 🚀 Project Overview
Complete Next.js/React platform for TCF (Test de Connaissance du Français) Canada exam preparation with:
- ✅ 4 quiz types (Compréhension Écrite/Orale, Expression Écrite/Orale)
- ✅ 39 questions per quiz
- ✅ Timer system (45 minutes per quiz)
- ✅ Instant correction and scoring
- ✅ Progress tracking dashboard
- ✅ Stripe payment integration
- ✅ Free + Premium subscription model
- ✅ User authentication
- ✅ Mobile-responsive design

---

## 📋 Quick Setup (15 minutes)

### 1. Clone & Install
```bash
npx create-next-app@latest tcf-canada --typescript --tailwind
cd tcf-canada

npm install next-auth@beta stripe @stripe/react-stripe-js @stripe/stripe-js
npm install supabase @supabase/supabase-js
npm install lucide-react
```

### 2. Environment Variables (.env.local)
```
# Authentication
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=generate-random-string-with: openssl rand -base64 32

# Stripe
NEXT_PUBLIC_STRIPE_PUBLIC_KEY=pk_test_xxxxx
STRIPE_SECRET_KEY=sk_test_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
STRIPE_PRICE_ID=price_xxxxx

# Supabase (or Firebase)
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=xxxxx
SUPABASE_SERVICE_ROLE_KEY=xxxxx

# App Config
NEXT_PUBLIC_APP_NAME="TCF Canada"
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. File Structure
```
tcf-canada/
├── app/
│   ├── api/
│   │   ├── auth/[...nextauth]/route.ts
│   │   ├── stripe/
│   │   │   ├── checkout/route.ts
│   │   │   └── webhooks/route.ts
│   │   ├── quizzes/[type]/route.ts
│   │   └── results/route.ts
│   ├── layout.tsx
│   ├── page.tsx
│   ├── dashboard/page.tsx
│   ├── quiz/[type]/page.tsx
│   └── results/[id]/page.tsx
├── components/
│   ├── QuizComponent.tsx
│   ├── Dashboard.tsx
│   ├── Timer.tsx
│   ├── SubscribeButton.tsx
│   └── ProtectedRoute.tsx
├── lib/
│   ├── supabase.ts
│   ├── stripe.ts
│   ├── quizData.ts
│   └── auth.ts
├── public/
│   └── images/
│       ├── 37q1.png
│       ├── 37q2.png
│       └── ... (28 images total)
└── data/
    └── quiz_questions.json
```

### 4. Start Development
```bash
npm run dev
# Visit http://localhost:3000
```

---

## 🗄️ Database Setup (Supabase)

### Create Tables

```sql
-- Users Table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  password_hash TEXT NOT NULL,
  subscription_type VARCHAR(20) DEFAULT 'free', -- free, premium, lifetime
  subscription_start TIMESTAMP,
  subscription_end TIMESTAMP,
  stripe_customer_id TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Quiz Questions
CREATE TABLE questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_type VARCHAR(50) NOT NULL, -- comprehension_ecrite, comprehension_orale, etc
  question_number INTEGER NOT NULL,
  text TEXT NOT NULL,
  question_prompt TEXT NOT NULL,
  image_url TEXT,
  audio_url TEXT,
  options JSONB NOT NULL,
  correct_answer VARCHAR(1) NOT NULL,
  difficulty VARCHAR(20), -- easy, medium, difficult
  created_at TIMESTAMP DEFAULT NOW()
);

-- Quiz Results
CREATE TABLE quiz_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  quiz_type VARCHAR(50) NOT NULL,
  score INTEGER NOT NULL,
  total_questions INTEGER NOT NULL,
  percentage INTEGER NOT NULL,
  time_spent INTEGER, -- in seconds
  answers JSONB NOT NULL,
  completed_at TIMESTAMP DEFAULT NOW()
);

-- Subscriptions
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  stripe_subscription_id TEXT,
  status VARCHAR(50), -- active, canceled, expired
  plan VARCHAR(50),
  current_period_start TIMESTAMP,
  current_period_end TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_questions_type ON questions(quiz_type);
CREATE INDEX idx_results_user ON quiz_results(user_id);
CREATE INDEX idx_results_date ON quiz_results(completed_at);
```

### Enable RLS (Row Level Security)
```sql
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own data"
  ON users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can view own results"
  ON quiz_results FOR SELECT
  USING (auth.uid() = user_id);
```

---

## 💳 Stripe Setup

### 1. Create Stripe Account & Products
- Go to https://dashboard.stripe.com
- Create Product: "TCF Canada Premium"
  - Monthly price: $19.99
  - Copy Price ID (price_xxx)

### 2. Create Webhook Endpoint
```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Listen for events
stripe listen --forward-to localhost:3000/api/stripe/webhooks

# Copy the signing secret
```

### 3. Update .env.local with Stripe credentials

---

## 🔐 Authentication Setup

### Create Auth API Route
**app/api/auth/[...nextauth]/route.ts**
```typescript
import NextAuth from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { supabase } from '@/lib/supabase'

export const authOptions = {
  providers: [
    CredentialsProvider({
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null

        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email: credentials.email,
            password: credentials.password
          })

          if (error || !data.user) return null

          // Get user subscription
          const { data: userData } = await supabase
            .from('users')
            .select('id, email, name, subscription_type')
            .eq('id', data.user.id)
            .single()

          return {
            id: data.user.id,
            email: data.user.email,
            name: userData?.name,
            subscription: userData?.subscription_type || 'free'
          }
        } catch (error) {
          console.error('Auth error:', error)
          return null
        }
      }
    })
  ],
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error'
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.subscription = user.subscription
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id
        session.user.subscription = token.subscription
      }
      return session
    }
  }
}

export const handler = NextAuth(authOptions)
```

---

## 📚 Load Quiz Data

### Import Questions
```typescript
// lib/quizData.ts
import quizData from '@/data/quiz_questions.json'

export async function getQuizzes(userId: string, type: string) {
  const { data: user } = await supabase
    .from('users')
    .select('subscription_type')
    .eq('id', userId)
    .single()

  // Get questions for quiz type
  const { data: questions } = await supabase
    .from('questions')
    .select('*')
    .eq('quiz_type', type)
    .order('question_number')

  // If free user, return only first 3 questions
  if (user?.subscription_type === 'free') {
    return questions?.slice(0, 3)
  }

  return questions
}
```

### Upload Images to Supabase Storage
```bash
# Create storage bucket
curl -X POST 'https://xxxxx.supabase.co/storage/v1/b' \
  -H 'Authorization: Bearer xxxxx' \
  -H 'Content-Type: application/json' \
  -d '{"name":"quiz-images","public":true}'

# Upload images from public/images folder to /quiz-images bucket
```

---

## 💰 Payment Integration

### Stripe Checkout
**app/api/stripe/checkout/route.ts**
```typescript
import Stripe from 'stripe'
import { getServerSession } from 'next-auth'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  
  if (!session?.user?.email) {
    return new Response('Unauthorized', { status: 401 })
  }

  const checkoutSession = await stripe.checkout.sessions.create({
    customer_email: session.user.email,
    payment_method_types: ['card'],
    line_items: [{
      price: process.env.STRIPE_PRICE_ID!,
      quantity: 1
    }],
    mode: 'subscription',
    success_url: `${process.env.NEXTAUTH_URL}/dashboard?success=true`,
    cancel_url: `${process.env.NEXTAUTH_URL}/pricing`,
    metadata: {
      user_id: session.user.id
    }
  })

  return Response.json({ sessionId: checkoutSession.id })
}
```

### Webhook Handler
**app/api/stripe/webhooks/route.ts**
```typescript
import Stripe from 'stripe'
import { headers } from 'next/headers'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(req: Request) {
  const body = await req.text()
  const signature = headers().get('Stripe-Signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err) {
    return new Response('Webhook Error', { status: 400 })
  }

  const subscription = event.data.object as Stripe.Subscription

  switch (event.type) {
    case 'customer.subscription.created':
    case 'customer.subscription.updated':
      // Update user subscription
      await supabase
        .from('users')
        .update({
          subscription_type: 'premium',
          subscription_start: new Date(subscription.created * 1000),
          subscription_end: new Date(subscription.current_period_end * 1000)
        })
        .eq('stripe_customer_id', subscription.customer)
      break

    case 'customer.subscription.deleted':
      // Downgrade to free
      await supabase
        .from('users')
        .update({
          subscription_type: 'free',
          subscription_end: null
        })
        .eq('stripe_customer_id', subscription.customer)
      break
  }

  return Response.json({ received: true })
}
```

---

## 📊 Quiz Results Tracking

### Save Results
```typescript
export async function saveQuizResult(
  userId: string,
  quizType: string,
  answers: Record<number, string>,
  timeSpent: number
) {
  // Get questions
  const { data: questions } = await supabase
    .from('questions')
    .select('correct_answer')
    .eq('quiz_type', quizType)

  // Calculate score
  let score = 0
  questions?.forEach((q, index) => {
    if (answers[index] === q.correct_answer) score++
  })

  // Save result
  const { data: result } = await supabase
    .from('quiz_results')
    .insert({
      user_id: userId,
      quiz_type: quizType,
      score,
      total_questions: questions?.length || 0,
      percentage: Math.round((score / (questions?.length || 1)) * 100),
      time_spent: timeSpent,
      answers,
      completed_at: new Date()
    })
    .select()
    .single()

  return result
}
```

---

## 🚀 Production Deployment

### Vercel Deployment
```bash
# Push to GitHub
git add .
git commit -m "Initial TCF Canada platform"
git push origin main

# Deploy to Vercel
vercel deploy --prod

# Set environment variables in Vercel dashboard
# Update Stripe webhook URL to: https://yourdomain.com/api/stripe/webhooks
```

### Important Checklist
- [ ] Update NEXTAUTH_URL to production URL
- [ ] Update Stripe webhook endpoint URL
- [ ] Enable HTTPS for all external URLs
- [ ] Set up email verification (optional)
- [ ] Configure CORS for API routes
- [ ] Enable database backups
- [ ] Set up monitoring & logging
- [ ] Create admin dashboard for managing quizzes
- [ ] Add analytics tracking
- [ ] Write privacy policy & terms of service

---

## 📱 Mobile Optimization

### Add Mobile Menu
```typescript
// components/MobileMenu.tsx
'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export function MobileMenu() {
  const [open, setOpen] = useState(false)

  return (
    <div className="md:hidden">
      <button onClick={() => setOpen(!open)}>
        {open ? <X /> : <Menu />}
      </button>
      {open && (
        <nav className="absolute top-16 left-0 right-0 bg-white shadow-lg">
          {/* Menu items */}
        </nav>
      )}
    </div>
  )
}
```

---

## 📈 Analytics & Monitoring

### Add Tracking
```typescript
// lib/analytics.ts
export function trackEvent(name: string, data?: any) {
  if (window.gtag) {
    window.gtag('event', name, data)
  }
}

// Usage
trackEvent('quiz_started', { type: 'comprehension_ecrite' })
trackEvent('quiz_completed', { score: 85, time: 2100 })
```

---

## 🆘 Troubleshooting

### Issue: Stripe Payment Not Working
- [ ] Check API keys are correct
- [ ] Verify webhook is connected
- [ ] Check browser console for errors
- [ ] Test with Stripe test cards: `4242 4242 4242 4242`

### Issue: Quiz Data Not Loading
- [ ] Check Supabase connection string
- [ ] Verify RLS policies are configured
- [ ] Check CORS settings
- [ ] Validate JSON data format

### Issue: Authentication Issues
- [ ] Clear cookies/cache
- [ ] Check NEXTAUTH_SECRET is set
- [ ] Verify Supabase auth is enabled
- [ ] Test with test user credentials

---

## 📞 Support & Next Steps

1. **Add Email Notifications**
   - Send completion certificates
   - Send weekly progress reports

2. **Add AI Features**
   - AI essay correction for Expression Écrite
   - Personalized quiz recommendations

3. **Add Social Features**
   - Leaderboards
   - Study groups
   - Discussion forums

4. **Add Analytics**
   - Advanced progress tracking
   - Learning patterns analysis
   - Weak areas identification

5. **Mobile App**
   - React Native version
   - Offline quiz capability
   - Push notifications

---

**Platform ready for launch! 🎉**
